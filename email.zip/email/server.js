const express = require('express');
const { SMTPServer } = require('smtp-server');
const { simpleParser } = require('mailparser');
const cors = require('cors');
const { randomUUID } = require('crypto');
const path = require('path');

const inMemoryEmails = []; // In-memory store

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Defaults to sumitbuilds.tech, but can be overridden in production
const DOMAIN = process.env.DOMAIN || 'sumitbuilds.tech';

app.get('/api/generate', (req, res) => {
  const customPrefix = req.query.custom;
  if (customPrefix) {
    const email = `${customPrefix.toLowerCase().replace(/[^a-z0-9]/g, '')}@${DOMAIN}`;
    return res.json({ email });
  }

  const adjectives = ['blue', 'happy', 'clever', 'fast', 'brave', 'silent', 'bright', 'cool', 'epic', 'wild', 'calm'];
  const nouns = ['tiger', 'eagle', 'river', 'stone', 'cloud', 'ocean', 'moon', 'star', 'mountain', 'forest', 'wolf'];
  
  const randomAdj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
  
  res.json({ email: `${randomAdj}${randomNoun}@${DOMAIN}` });
});

app.get('/api/emails/:address', (req, res) => {
  const address = req.params.address.toLowerCase();
  
  const userEmails = inMemoryEmails
    .filter(e => e.recipient === address)
    .sort((a, b) => new Date(b.date) - new Date(a.date));
    
  res.json(userEmails);
});

// Configure SMTP server
const smtp = new SMTPServer({
  authOptional: true,
  onData(stream, session, callback) {
    simpleParser(stream, async (err, parsed) => {
      if (err) {
        console.error('Mail parser error:', err);
        return callback();
      }

      // Check recipient
      if (!parsed.to || !parsed.to.value) return callback();
      
      const recipients = parsed.to.value.map(val => val.address.toLowerCase());
      const sender = parsed.from.value[0].address;
      const subject = parsed.subject || 'No Subject';
      const text = parsed.text || '';
      const html = parsed.html || '';
      const date = parsed.date || new Date();

      for (let recipient of recipients) {
        inMemoryEmails.push({
          id: randomUUID(),
          recipient,
          sender,
          subject,
          date: date.toISOString(),
          text,
          html
        });
      }
      
      callback();
    });
  }
});

const HTTP_PORT = process.env.PORT || 3005;
const SMTP_PORT = process.env.SMTP_PORT || 2525;

app.listen(HTTP_PORT, () => {
  console.log(`HTTP API running on port ${HTTP_PORT}`);
});

smtp.listen(SMTP_PORT, () => {
  console.log(`SMTP server running on port ${SMTP_PORT}`);
});
smtp.on('error', (err) => {
  console.error('SMTP Error (Port 25 may require administrator privileges):', err.message);
});
