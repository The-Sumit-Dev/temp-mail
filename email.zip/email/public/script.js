const API_BASE = 'http://localhost:3005/api';
let currentEmail = '';
let pollInterval = null;

// Actions
const currentEmailEl = document.getElementById('current-email');
const btnCopyEmail = document.getElementById('btn-copy-email');
const btnRefresh = document.getElementById('btn-refresh');
const copyToast = document.getElementById('copy-toast');
const inboxList = document.getElementById('inbox-list');

// Dropdown Menu
const btnCmdMenu = document.getElementById('btn-cmd-menu');
const cmdDropdown = document.getElementById('cmd-dropdown');
const btnRandom = document.getElementById('btn-random');
const btnCustom = document.getElementById('btn-custom');

// Modal Elements
const modal = document.getElementById('email-modal');
const btnCloseModal = document.getElementById('btn-close-modal');
const mSubject = document.getElementById('modal-subject');
const mFrom = document.getElementById('modal-from');
const mDate = document.getElementById('modal-date');
const mBody = document.getElementById('modal-body');

// Custom Email Modal Elements
const customModal = document.getElementById('custom-modal');
const btnCloseCustom = document.getElementById('btn-close-custom');
const customPrefixInput = document.getElementById('custom-prefix-input');
const btnSubmitCustom = document.getElementById('btn-submit-custom');

window.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('sumit_email_session');
  if (saved) {
    setEmail(saved);
  } else {
    generateRandom();
  }
});

// Dropdown Toggle
btnCmdMenu.addEventListener('click', (e) => {
  e.stopPropagation();
  cmdDropdown.classList.toggle('show');
});

// Close dropdown when clicking outside
window.addEventListener('click', () => {
  if (cmdDropdown.classList.contains('show')) {
    cmdDropdown.classList.remove('show');
  }
});

btnRandom.addEventListener('click', () => {
  cmdDropdown.classList.remove('show');
  generateRandom();
});

btnCustom.addEventListener('click', () => {
  cmdDropdown.classList.remove('show');
  // Open Custom Modal rather than prompt
  customPrefixInput.value = '';
  customModal.classList.add('active');
  customPrefixInput.focus();
});

// Custom Modal Interactions
btnCloseCustom.addEventListener('click', () => {
  customModal.classList.remove('active');
});

btnSubmitCustom.addEventListener('click', () => {
  const prefix = customPrefixInput.value.trim();
  if (prefix) {
    customModal.classList.remove('active');
    generateCustom(prefix);
  }
});

customPrefixInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    btnSubmitCustom.click();
  }
});

btnCopyEmail.addEventListener('click', () => {
  if (!currentEmail) return;
  navigator.clipboard.writeText(currentEmail).then(() => {
    btnCopyEmail.classList.add('copied');
    setTimeout(() => btnCopyEmail.classList.remove('copied'), 600);
    
    copyToast.classList.add('show');
    setTimeout(() => copyToast.classList.remove('show'), 2000);
  });
});

btnRefresh.addEventListener('click', () => {
  const icon = btnRefresh.querySelector('i');
  icon.classList.add('ph-spinner', 'spin');
  fetchInbox().then(() => {
    setTimeout(() => {
      icon.classList.remove('ph-spinner', 'spin');
    }, 500);
  });
});

async function generateRandom() {
  currentEmailEl.textContent = 'Generating...';
  try {
    const res = await fetch(`${API_BASE}/generate`);
    const data = await res.json();
    setEmail(data.email);
  } catch (err) {
    console.error(err);
  }
}

async function generateCustom(prefix) {
  currentEmailEl.textContent = 'Generating...';
  try {
    const res = await fetch(`${API_BASE}/generate?custom=${encodeURIComponent(prefix)}`);
    const data = await res.json();
    setEmail(data.email);
  } catch (err) {
    console.error(err);
  }
}

function setEmail(email) {
  currentEmail = email;
  currentEmailEl.textContent = email;
  localStorage.setItem('sumit_email_session', email);
  startPolling();
  fetchInbox();
}

function startPolling() {
  if (pollInterval) clearInterval(pollInterval);
  // Auto-refresh every 5 seconds as requested!
  pollInterval = setInterval(fetchInbox, 5000);
}

async function fetchInbox() {
  if (!currentEmail) return;
  try {
    const res = await fetch(`${API_BASE}/emails/${encodeURIComponent(currentEmail)}`);
    const emails = await res.json();
    renderInbox(emails);
  } catch (err) {
    console.error(err);
  }
}

function renderInbox(emails) {
  if (emails.length === 0) {
    inboxList.innerHTML = `
      <div class="empty-state">
        <div style="font-size: 2rem; color: #444; margin-bottom: 0.5rem;"><i class="ph ph-envelope-simple"></i></div>
        Waiting for incoming emails... Auto-refreshing every 5s.
      </div>
    `;
    return;
  }

  inboxList.innerHTML = '';
  emails.forEach(email => {
    const el = document.createElement('div');
    el.className = 'email-item';
    
    const dateStr = new Date(email.date).toLocaleString(undefined, { 
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' 
    });

    const snippet = escapeHTML(email.text || email.subject).substring(0, 100) + '...';

    el.innerHTML = `
      <div class="email-top">
        <span class="email-sender">${escapeHTML(email.sender)}</span>
        <span class="email-date">${dateStr}</span>
      </div>
      <div class="email-subject">${escapeHTML(email.subject || 'No Subject')}</div>
    `;

    el.addEventListener('click', () => openModal(email));
    inboxList.appendChild(el);
  });
}

function openModal(email) {
  mSubject.textContent = email.subject || 'No Subject';
  mFrom.textContent = email.sender;
  mDate.textContent = new Date(email.date).toLocaleString();
  
  if (email.html) {
    mBody.innerHTML = email.html;
  } else {
    mBody.innerHTML = `<pre style="white-space: pre-wrap; font-family: inherit;">${escapeHTML(email.text)}</pre>`;
  }
  
  modal.classList.add('active');
}

btnCloseModal.addEventListener('click', () => modal.classList.remove('active'));
modal.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.remove('active');
});

function escapeHTML(str) {
  if (!str) return '';
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}
