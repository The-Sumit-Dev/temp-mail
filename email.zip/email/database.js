const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'emails.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS emails (
      id TEXT PRIMARY KEY,
      recipient TEXT,
      sender TEXT,
      subject TEXT,
      date TEXT,
      text TEXT,
      html TEXT
    )
  `);
});

module.exports = db;
